<html>
<head>Base de datos conectada con postgres SQL</head>
<BR>
<body>
<?php
	$conexion = mysqli_connect("mysql.webcindario.com","pruebabdkl","salcedo99","pruebabdkl");
	echo "Datos de la tabla vendedor";
	echo "<BR>";
	$sql="select *from vendedor";
	$resultado_set=mysqli_connect($conexion, "SELECT * FROM vendedor");
	    while($row=mysqli_fetch_array($resultado_set){
	     echo $row["cod_vendedor"]."--->".$row["nom_vendedor"];
	     echo "<BR>";
	   }
	   mysqli_close($conexion);
?>
</body>
</html>