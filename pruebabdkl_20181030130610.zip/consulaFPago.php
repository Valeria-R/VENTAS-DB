<html>
<head>Base de datos conectada con  MYSQL</head>
<BR>
<body>
<?php
	$conexion = mysqli_connect("mysql.webcindario.com","pruebabdkl","salcedo99","pruebabdkl");
	echo "Datos de la tabla f_pago";
	echo "<BR>";
	$sql="SELECT * FROM f_pago";
	$resultado_set=mysqli_query($conexion, $sql);
	    while($row=mysqli_fetch_array($resultado_set)){
	     echo $row["cod_f_pago"]."--->".$row["nom_f_pago"];
	     echo "<BR>";
	   }
	   mysqli_close($conexion);
?>
</body>
</html>