<html>
<head>Base de datos conectada con postgres SQL</head>
<BR>
<body>
<?php
	$v_usuario=  $_POST["username"];
	$v_password= $_POST["password"];
	$v_tabla=    $_POST["tabla"];
	$conexion = mysqli_connect("mysql.webcindario.com","pruebabdkl","salcedo99","pruebabdkl");
	echo "Datos de la tabla $v_tabla";
	echo "<BR>";

	if($v_tabla=="factura"){
	$sql="select * from factura";
	$resultado_set=mysqli_connect($conexion, $sql);
	  while($row=mysqli_fetch_array($resultado_set)){
	      echo $row["cod_factura"]."--->".$row["cod_cliente"]."--->" .$row["val_factura"];
	      echo "<BR>";
	 }
	};
	if ($v_tabla=="cliente"){
	$sql="select *from cliente";
	$resultado_set=mysqli_connect($conexion, $sql);
	    while($row=mysqli_fetch_array($resultado_set)){
	     echo $row["cod_cliente"]."--->".$row["nom_cliente"]."--->".$row["cod_ciudad"]."--->".$row["cod_vendedor"]."--->".$row["cod_f_pago"];
	     echo "<BR>";
	   }
	};
	if ($v_tabla=="ciudad"){
	$sql="select *from ciudad";
	$resultado_set=mysqli_connect($conexion, $sql);
	    while($row=mysqli_fetch_array($resultado_set)){
	     echo $row["cod_ciudad"]."--->".$row["nom_ciudad"];
	     echo "<BR>";
	   }
	};
	if ($v_tabla=="f_pago"){
	$sql="select *from f_pago";
	$resultado_set=mysqli_connect($conexion, $sql);
	    while($row=mysqli_fetch_array($resultado_set)){
	     echo $row["cod_f_pago"]."--->".$row["nom_f_pago"];
	     echo "<BR>";
	   }
	};
	if ($v_tabla=="vendedor"){
	$sql="select *from vendedor";
	$resultado_set=mysqli_connect($conexion, $sql);
	    while($row=mysqli_fetch_array($resultado_set)){
	     echo $row["cod_vendedor"]."--->".$row["nom_vendedor"];
	     echo "<BR>";
	   }
	};
	mysqli_close($conexion);
?>
</body>
</html>